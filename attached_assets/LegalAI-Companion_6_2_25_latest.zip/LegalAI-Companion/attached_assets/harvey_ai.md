URL: https://www.harvey.ai/
---
Products

- [Assistant](https://www.harvey.ai/products/assistant)
- [Vault](https://www.harvey.ai/products/vault)
- [Knowledge](https://www.harvey.ai/products/knowledge)
- [Workflows](https://www.harvey.ai/products/workflows)

- [Customers](https://www.harvey.ai/customers)
- [Security](https://www.harvey.ai/security)
- [News](https://www.harvey.ai/news)
- [Company](https://www.harvey.ai/company)

Contact Us

[Login](https://app.harvey.ai/)

# Professional

# Class AI

Domain-specific AI for law firms, professional service providers, and the Fortune 500.

Contact Us

![Video thumbnail](https://www.harvey.ai/_next/image?url=%2Fimages%2Fvideo-poster.png&w=3840&q=75)

Watch Film

### Built for Industry Leaders

![vinson elkins logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F4bc5bff74e87df5141611c09858d9d4f7b97a3d2-399x200.svg%3Fauto%3Dformat&w=3840&q=10)![schonherr logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F3e05db79a1f5a9735d5ad2bac652e9811b719448-310x200.svg%3Fauto%3Dformat&w=3840&q=10)![t](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fb4430a3afa5e57c925e3e326ae65dce26f5190be-63x198.svg%3Fauto%3Dformat&w=3840&q=10)![repsol logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F2bdce6901c1b3d380102f32da7406eab0267d0d9-330x200.svg%3Fauto%3Dformat&w=3840&q=10)![reed logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fc332f53c986a0b0e806cbc69d89ccba1e36577c8-293x200.svg%3Fauto%3Dformat&w=3840&q=10)![pwc logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F5073b714b2bd7632442ba1b300a3e10ee73bc401-99x143.svg%3Frect%3D2%2C0%2C97%2C143%26auto%3Dformat&w=3840&q=10)![omelveny logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F75dee48504748d911bcade275663283e3b0595b3-307x200.svg%3Fauto%3Dformat&w=3840&q=10)![bridgewater logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F85215fdd1f52d4d1be7974d0dbb972f7cefa79ec-364x200.svg%3Fauto%3Dformat&w=3840&q=10)![macfarlanes logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F103b8c602a5a526b370ef025f4ecc9fbd9b6d043-413x198.svg%3Fauto%3Dformat&w=3840&q=10)![kkr logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fce129140f5a82325ee3dc80604df1f24ef25fa07-162x200.svg%3Fauto%3Dformat&w=3840&q=10)![A&O SheaRman](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F58b685d5da40f8c0f102f1a8d735fc2d2e8e4e03-477x200.svg%3Fauto%3Dformat&w=3840&q=10)![gleiss logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F7753ddb55985d69c7338b86b4361968ed6981ff6-318x200.svg%3Fauto%3Dformat&w=3840&q=10)![cms logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F8d5aa6083a827c531b0975274fc3e0c0d59b9fb3-167x200.svg%3Fauto%3Dformat&w=3840&q=10)![cuatrecasas logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fbcad5d86c873fe5afc6cffafae94fa729588715f-289x200.svg%3Fauto%3Dformat&w=3840&q=10)![vinson elkins logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F4bc5bff74e87df5141611c09858d9d4f7b97a3d2-399x200.svg%3Fauto%3Dformat&w=3840&q=10)![schonherr logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F3e05db79a1f5a9735d5ad2bac652e9811b719448-310x200.svg%3Fauto%3Dformat&w=3840&q=10)![t](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fb4430a3afa5e57c925e3e326ae65dce26f5190be-63x198.svg%3Fauto%3Dformat&w=3840&q=10)![repsol logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F2bdce6901c1b3d380102f32da7406eab0267d0d9-330x200.svg%3Fauto%3Dformat&w=3840&q=10)![reed logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fc332f53c986a0b0e806cbc69d89ccba1e36577c8-293x200.svg%3Fauto%3Dformat&w=3840&q=10)![pwc logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F5073b714b2bd7632442ba1b300a3e10ee73bc401-99x143.svg%3Frect%3D2%2C0%2C97%2C143%26auto%3Dformat&w=3840&q=10)![omelveny logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F75dee48504748d911bcade275663283e3b0595b3-307x200.svg%3Fauto%3Dformat&w=3840&q=10)![bridgewater logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F85215fdd1f52d4d1be7974d0dbb972f7cefa79ec-364x200.svg%3Fauto%3Dformat&w=3840&q=10)![macfarlanes logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F103b8c602a5a526b370ef025f4ecc9fbd9b6d043-413x198.svg%3Fauto%3Dformat&w=3840&q=10)![kkr logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fce129140f5a82325ee3dc80604df1f24ef25fa07-162x200.svg%3Fauto%3Dformat&w=3840&q=10)![A&O SheaRman](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F58b685d5da40f8c0f102f1a8d735fc2d2e8e4e03-477x200.svg%3Fauto%3Dformat&w=3840&q=10)![gleiss logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F7753ddb55985d69c7338b86b4361968ed6981ff6-318x200.svg%3Fauto%3Dformat&w=3840&q=10)![cms logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F8d5aa6083a827c531b0975274fc3e0c0d59b9fb3-167x200.svg%3Fauto%3Dformat&w=3840&q=10)![cuatrecasas logo](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fbcad5d86c873fe5afc6cffafae94fa729588715f-289x200.svg%3Fauto%3Dformat&w=3840&q=10)

[See Customers](https://www.harvey.ai/customers)

### Augment All of Your Work on

### One Integrated, Secure Platform

![](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fc7276a153957d7a565f735a7a515a4d67d78d59d-1000x1000.png%3Fauto%3Dformat&w=3840&q=90)

Assistant

## Tailored to Your Expertise

Delegate complex tasks in natural language to your domain-specific personal assistant.

[Explore Assistant](https://www.harvey.ai/products/assistant)

![](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F560eef627d9b1bc21d0196158683e98b4420921e-1108x1108.png%3Fauto%3Dformat&w=3840&q=90)

Knowledge

## Rapid Research, Grounded Results

Get answers to complex research questions across multiple domains in legal, regulatory, and tax with accurate citations.​​​​‌﻿‍﻿​‍​‍‌‍﻿﻿‌﻿​‍‌‍‍‌‌‍‌﻿‌‍‍‌‌‍﻿‍​‍​‍​﻿‍‍​‍​‍‌﻿​﻿‌‍​‌‌‍﻿‍‌‍‍‌‌﻿‌​‌﻿‍‌​‍﻿‍‌‍‍‌‌‍﻿﻿​‍​‍​‍﻿​​‍​‍‌‍‍​‌﻿​‍‌‍‌‌‌‍‌‍​‍​‍​﻿‍‍​‍​‍​‍﻿﻿‌﻿​﻿‌﻿‌​‌﻿‌‌‌‍‌​‌‍‍‌‌‍﻿﻿​‍﻿﻿‌‍‍‌‌‍﻿‍‌﻿‌​‌‍‌‌‌‍﻿‍‌﻿‌​​‍﻿﻿‌‍‌‌‌‍‌​‌‍‍‌‌﻿‌​​‍﻿﻿‌‍﻿‌‌‍﻿﻿‌‍‌​‌‍‌‌​﻿﻿‌‌﻿​​‌﻿​‍‌‍‌‌‌﻿​﻿‌‍‌‌‌‍﻿‍‌﻿‌​‌‍​‌‌﻿‌​‌‍‍‌‌‍﻿﻿‌‍﻿‍​﻿‍﻿‌‍‍‌‌‍‌​​﻿﻿‌‌﻿​‍‌‍‌‌‌﻿​﻿‌‍‌‌‌‍​‌‌﻿​‍‌‍​﻿‌‍‍​‌‌​​‌‍​‌‌‍‌﻿‌‍‌‌​﻿‍﻿‌﻿‌​‌﻿‍‌‌﻿​​‌‍‌‌​﻿﻿‌‌﻿​‍‌‍‌‌‌﻿​﻿‌‍‌‌‌‍​‌‌﻿​‍‌‍​﻿‌‍‍​‌‌​​‌‍​‌‌‍‌﻿‌‍‌‌​﻿‍﻿‌﻿​​‌‍​‌‌﻿‌​‌‍‍​​﻿﻿‌‌‍‍​‌‍‌‌‌﻿​‍‌‍﻿﻿‌‌​﻿‌‍‌‌‌‍​﻿‌﻿‌​‌‍‍‌‌‍﻿﻿‌‍﻿‍​‍﻿‍‌﻿​﻿‌﻿‌‌‌‍​‍‌‍‍​‌‍‌‌‌‍​‌‌‍‌​‌‍﻿​‌‍‍‌‌‍﻿‍‌‍‌‌​﻿﻿﻿‌‍​‍‌‍​‌‌﻿​﻿‌‍‌‌‌‌‌‌‌﻿​‍‌‍﻿​​﻿﻿‌​‍‌‌​﻿​‍‌​‌‍‌﻿​﻿‌﻿‌​‌﻿‌‌‌‍‌​‌‍‍‌‌‍﻿﻿​‍‌‍‌‍‍‌‌‍‌​​﻿﻿‌‌﻿​‍‌‍‌‌‌﻿​﻿‌‍‌‌‌‍​‌‌﻿​‍‌‍​﻿‌‍‍​‌‌​​‌‍​‌‌‍‌﻿‌‍‌‌​‍‌‍‌﻿‌​‌﻿‍‌‌﻿​​‌‍‌‌​﻿﻿‌‌﻿​‍‌‍‌‌‌﻿​﻿‌‍‌‌‌‍​‌‌﻿​‍‌‍​﻿‌‍‍​‌‌​​‌‍​‌‌‍‌﻿‌‍‌‌​‍‌‍‌﻿​​‌‍​‌‌﻿‌​‌‍‍​​﻿﻿‌‌‍‍​‌‍‌‌‌﻿​‍‌‍﻿﻿‌‌​﻿‌‍‌‌‌‍​﻿‌﻿‌​‌‍‍‌‌‍﻿﻿‌‍﻿‍​‍﻿‍‌﻿​﻿‌﻿‌‌‌‍​‍‌‍‍​‌‍‌‌‌‍​‌‌‍‌​‌‍﻿​‌‍‍‌‌‍﻿‍‌‍‌‌​‍​‍‌﻿﻿‌

[Explore Knowledge](https://www.harvey.ai/products/knowledge)

![](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Ffaa9a8479f141e6cd4013009a40db252eb446b71-1108x1108.png%3Fauto%3Dformat&w=3840&q=90)

Vault

## Secure Project Workspaces

Upload, store, and analyze thousands of documents using powerful generative AI.

[Explore Vault](https://www.harvey.ai/products/vault)

![](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F7f73b08e25dc322155081e65faea8d57cee1f92b-1108x1108.png%3Fauto%3Dformat&w=3840&q=90)

Workflows

## Streamline Your Work

Multi-model agents designed to collaborate with professionals to deliver precise, purpose-built work product. More coming soon.

[Explore Workflows](https://www.harvey.ai/products/workflows)

### Unlock Professional Class AI For Your Firm​​​​‌﻿‍﻿​‍​‍‌‍﻿﻿‌﻿​‍‌‍‍‌‌‍‌﻿‌‍‍‌‌‍﻿‍​‍​‍​﻿‍‍​‍​‍‌﻿​﻿‌‍​‌‌‍﻿‍‌‍‍‌‌﻿‌​‌﻿‍‌​‍﻿‍‌‍‍‌‌‍﻿﻿​‍​‍​‍﻿​​‍​‍‌‍‍​‌﻿​‍‌‍‌‌‌‍‌‍​‍​‍​﻿‍‍​‍​‍​‍﻿﻿‌﻿​﻿‌﻿‌​‌﻿‌‌‌‍‌​‌‍‍‌‌‍﻿﻿​‍﻿﻿‌‍‍‌‌‍﻿‍‌﻿‌​‌‍‌‌‌‍﻿‍‌﻿‌​​‍﻿﻿‌‍‌‌‌‍‌​‌‍‍‌‌﻿‌​​‍﻿﻿‌‍﻿‌‌‍﻿﻿‌‍‌​‌‍‌‌​﻿﻿‌‌﻿​​‌﻿​‍‌‍‌‌‌﻿​﻿‌‍‌‌‌‍﻿‍‌﻿‌​‌‍​‌‌﻿‌​‌‍‍‌‌‍﻿﻿‌‍﻿‍​﻿‍﻿‌‍‍‌‌‍‌​​﻿﻿‌‌‍‌‍‌‍﻿﻿‌‍﻿﻿‌﻿‌​‌‍‌‌‌﻿​‍​﻿‍﻿‌﻿‌​‌﻿‍‌‌﻿​​‌‍‌‌​﻿﻿‌‌‍‌‍‌‍﻿﻿‌‍﻿﻿‌﻿‌​‌‍‌‌‌﻿​‍​﻿‍﻿‌﻿​​‌‍​‌‌﻿‌​‌‍‍​​﻿﻿‌‌‍‍​‌‍‌‌‌‍​‌‌‍‌​‌‍﻿​‌‍‍‌‌‍﻿‍‌‍‌‌​﻿﻿﻿‌‍​‍‌‍​‌‌﻿​﻿‌‍‌‌‌‌‌‌‌﻿​‍‌‍﻿​​﻿﻿‌​‍‌‌​﻿​‍‌​‌‍‌﻿​﻿‌﻿‌​‌﻿‌‌‌‍‌​‌‍‍‌‌‍﻿﻿​‍‌‍‌‍‍‌‌‍‌​​﻿﻿‌‌‍‌‍‌‍﻿﻿‌‍﻿﻿‌﻿‌​‌‍‌‌‌﻿​‍​‍‌‍‌﻿‌​‌﻿‍‌‌﻿​​‌‍‌‌​﻿﻿‌‌‍‌‍‌‍﻿﻿‌‍﻿﻿‌﻿‌​‌‍‌‌‌﻿​‍​‍‌‍‌﻿​​‌‍​‌‌﻿‌​‌‍‍​​﻿﻿‌‌‍‍​‌‍‌‌‌‍​‌‌‍‌​‌‍﻿​‌‍‍‌‌‍﻿‍‌‍‌‌​‍​‍‌﻿﻿‌

![Alt](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F4a6b7e8a51dedcac24be4e8ee08a8332252f7f4a-36x36.svg%3Fauto%3Dformat&w=3840&q=90)

#### Enterprise-Grade Security

Robust, industry-standard protection with zero training on your data.

![alt](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2F1995f9bed993e51aaa29f9c4f08b4a747ff0ffa4-37x36.svg%3Fauto%3Dformat&w=3840&q=90)

#### Prompt Libraries

A collection of expertly-curated prompts and examples at your fingertips.

![alt](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fff0febed1de52e4e557c7e2eb61b4edeec5194cf-37x36.svg%3Fauto%3Dformat&w=3840&q=90)

#### Domain-Specific Models

High-performing custom models built for complex professional work.

![Claudia Junker ](https://www.harvey.ai/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F07s0r5r6%2Fproduction%2Fbb30078fe97208d23e0c4b180ae53904abfa19dc-5437x8152.jpg%3Frect%3D8%2C644%2C4742%2C4246%26auto%3Dformat&w=3840&q=75)

> “We want to free the lawyer from mundane, routine tasks, so that they can focus on what matters — strategy, advice, and judgment. This has become the mantra for my team.”

David Wakeling

Global Head of Markets Innovation Group (MIG) and AI Advisory Practice, A&O Shearman

### Unlock professional class AI for your firm

Contact Us