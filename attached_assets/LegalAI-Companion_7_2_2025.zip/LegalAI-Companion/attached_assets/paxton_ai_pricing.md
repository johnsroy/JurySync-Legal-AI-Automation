URL: https://www.paxton.ai/pricing
---
### Pricing

[Monthly](https://www.paxton.ai/pricing#w-tabs-0-data-w-pane-0) [Yearly](https://www.paxton.ai/pricing#w-tabs-0-data-w-pane-1)

#### Student

For the budding legal minds. Access all the features of Paxton.

(Sign up with a .edu email for the Student Rate)

##### $29/user/month

[Connect](https://app.paxton.ai/sign-up?)

Full access to our all-in-one AI legal assistant

Discounted rate geared for students

Free 7 Day Trial

#### Professional

Designed for legal professionals who want to apply cutting-edge AI to their legal work.

‍

##### $199/user/month

[Start Your Free Trial](https://app.paxton.ai/sign-up?)

Full access to our all-in-one AI legal assistant

Drafting assistance for memos, emails, legal briefs, and more

Comprehensive Federal and State regulations knowledge base

Custom document uploads for personalized insights

Streamlined Contract Review with AI insights

Regulatory compliance reviews for your documents

Intuitive Boolean search composer

#### Enterprise

Built for law firms and corporate and corporate legal departments looking for enhanced security

and collaboration features.

##### Customized Quote  ‍

[Contact Us](mailto:hello@paxton.ai?subject=Paxton%20AI%20%20-%20Custom%20Inquiry)

**All the benefits of the Professional Plan**

Single Sign-On (SSO) for enhanced security

Advanced user management capabilities

Collaboration features for shared document sets

Dedicated support and account manager

#### Student

For the budding legal minds. Access all the features of Paxton.

(Sign up with a .edu email for the Student Rate)

##### $25/user/month

$300/year **$348** _(Save 14%)_

[Connect](https://app.paxton.ai/sign-up?)

Full access to our all-in-one AI legal assistant

Discounted rate geared for students

Save 20% + Free 7 Day Trial

#### Professional

Designed for legal professionals who want to apply cutting-edge AI to their legal work.

‍

##### $159/user/month

$1,908/year **$2,388** _(Save 20%)_

[Start Your Free Trial](https://app.paxton.ai/sign-up?)

Full access to our all-in-one AI legal assistant

Drafting assistance for memos, emails, legal briefs, and more

Comprehensive Federal and State regulations knowledge base

Custom document uploads for personalized insights

Streamlined Contract Review with AI insights

Regulatory compliance reviews for your documents

Search laws, case laws and regulations

#### Enterprise

Built for law firms and corporate and corporate legal departments looking for enhanced security

and collaboration features.

##### Customized Quote

[Contact Us](mailto:hello@paxton.ai?subject=Paxton%20AI%20%20-%20Custom%20Inquiry)

**All the benefits of the Professional Plan**

Single Sign-On (SSO) for enhanced security

Advanced user management capabilities

Collaboration features for shared document sets

Dedicated support and account manager